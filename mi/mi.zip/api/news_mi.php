<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

$file = __DIR__ . '/news_mi.json';
$overridesFile = __DIR__ . '/news_mi_overrides.json';

if (!file_exists($file)) {
    file_put_contents($file, '[]');
}

function getShortcode($item) {
    $link = $item['link'] ?? '';
    if (preg_match('/instagram\.com\/(?:p|reel|tv)\/([A-Za-z0-9_-]+)/i', $link, $m)) return $m[1];
    return isset($item['shortcode']) ? $item['shortcode'] : null;
}

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($method === 'GET') {
    $data = json_decode(file_get_contents($file), true);
    if (!is_array($data)) $data = [];
    $overrides = [];
    if (file_exists($overridesFile)) {
        $overrides = json_decode(file_get_contents($overridesFile), true);
        if (!is_array($overrides)) $overrides = [];
    }
    foreach ($data as &$item) {
        $sc = getShortcode($item);
        if ($sc && isset($overrides[$sc]) && $overrides[$sc] !== '') {
            $item['img'] = $overrides[$sc];
        }
    }
    unset($item);
    echo json_encode($data);
    exit;
}

if ($method === 'POST') {
    session_start();
    if (!isset($_SESSION['is_admin_logged_in']) || $_SESSION['is_admin_logged_in'] !== true) {
        http_response_code(403);
        echo json_encode(['error' => 'Unauthorized']);
        exit;
    }
    $input = json_decode(file_get_contents('php://input'), true);
    if (!$input) $input = [];

    if (isset($input['action']) && $input['action'] === 'set_override') {
        $shortcode = isset($input['shortcode']) ? trim($input['shortcode']) : '';
        $img = isset($input['img']) ? trim($input['img']) : '';
        if ($shortcode === '') {
            echo json_encode(['success' => false, 'error' => 'shortcode wajib']);
            exit;
        }
        $overrides = [];
        if (file_exists($overridesFile)) {
            $overrides = json_decode(file_get_contents($overridesFile), true);
            if (!is_array($overrides)) $overrides = [];
        }
        if ($img === '') {
            unset($overrides[$shortcode]);
        } else {
            $overrides[$shortcode] = $img;
        }
        $result = file_put_contents($overridesFile, json_encode($overrides, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
        echo json_encode($result !== false ? ['success' => true] : ['success' => false, 'error' => 'Gagal menulis overrides']);
        exit;
    }

    if (!isset($input['all_news']) || !is_array($input['all_news'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Format data tidak valid.']);
        exit;
    }
    $result = file_put_contents($file, json_encode($input['all_news'], JSON_PRETTY_PRINT));
    echo json_encode($result !== false ? ['success' => true, 'bytes' => $result] : ['success' => false, 'error' => 'Gagal menulis']);
    exit;
}

if ($method === 'OPTIONS') {
    http_response_code(200);
    exit;
}

http_response_code(405);
echo json_encode(['error' => 'Method not allowed']);
