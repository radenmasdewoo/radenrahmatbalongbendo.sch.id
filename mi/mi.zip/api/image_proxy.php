<?php
/**
 * Media proxy (image/video) untuk MI Raden Rahmat
 * Mendukung proxy URL CDN Instagram dan fallback Shortcode size=l
 */

function resolve_local(string $shortcode): string {
    $sc = preg_replace('/[^A-Za-z0-9_-]/', '', $shortcode);
    if ($sc === '') return '';
    $path = __DIR__ . "/ig_cache/{$sc}.jpg";
    return file_exists($path) ? "api/ig_cache/{$sc}.jpg" : "";
}

$url = trim((string)($_GET['url'] ?? ''));
$sc  = trim((string)($_GET['shortcode'] ?? ''));
$kind = strtolower(trim((string)($_GET['kind'] ?? 'image')));
if ($kind !== 'video') $kind = 'image';

// 1. Jika ada shortcode & image, coba size=l langsung sebagai target URL jika tidak ada URL CDN
if ($url === '' && $sc !== '' && $kind === 'image') {
    $url = "https://www.instagram.com/p/{$sc}/media/?size=l";
}

// 2. Jika masih kosong, coba resolve dari cache lokal
if ($url === '' && $sc !== '') {
    $url = resolve_local($sc);
}

// 3. Jika null — 1x1 GIF
if ($url === '') {
    header('Content-Type: image/gif');
    echo base64_decode('R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw==');
    exit;
}

// 4. Serve file lokal langsung (cegah path traversal)
if (!preg_match('/^https?:\/\//i', $url)) {
    $url = str_replace('\\', '/', $url);
    if (strpos($url, '..') !== false) {
        header('Content-Type: image/gif');
        echo base64_decode('R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw==');
        exit;
    }
    $fullPath = __DIR__ . '/../' . ltrim($url, '/');
    $real = @realpath($fullPath);
    $base = realpath(__DIR__);
    if ($real !== false && $base !== false && strpos($real, $base) === 0 && file_exists($real) && is_file($real)) {
        header('Content-Type: ' . (strpos($real, '.mp4') !== false ? 'video/mp4' : 'image/jpeg'));
        header('Cache-Control: public, max-age=86400');
        readfile($real);
        exit;
    }
}

// 5. Proxy URL remote via cURL
$ch = curl_init($url);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_MAXREDIRS      => 5,
    CURLOPT_TIMEOUT        => 20,
    CURLOPT_HTTPHEADER     => [
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'Referer: https://www.instagram.com/',
    ],
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_SSL_VERIFYHOST => false,
]);

$body = curl_exec($ch);
$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$type = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
curl_close($ch);

if ($code >= 200 && $code < 300 && $body) {
    header('Content-Type: ' . ($type ?: ($kind === 'video' ? 'video/mp4' : 'image/jpeg')));
    header('Cache-Control: public, max-age=86400');
    header('Access-Control-Allow-Origin: *');
    echo $body;
} else {
    header('Content-Type: image/gif');
    echo base64_decode('R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw==');
}
