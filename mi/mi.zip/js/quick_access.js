// Quick Access System for Super Admin
// Ctrl+Shift+L to access dashboard from any page

(function () {
    'use strict';

    // Check if already in superadmin dashboard
    if (window.location.pathname.includes('/superadmin')) {
        return; // Don't run on dashboard itself
    }

    // Keyboard shortcut listener
    document.addEventListener('keydown', function (e) {
        // Ctrl+Shift+L
        if (e.ctrlKey && e.shiftKey && e.key === 'L') {
            e.preventDefault();
            showQuickLogin();
        }
    });

    let loginAttempts = 0;

    // Show login modal
    function showQuickLogin() {
        // Check if modal already exists
        if (document.getElementById('quick-login-modal')) {
            document.getElementById('quick-login-modal').style.display = 'flex';
            document.getElementById('quick-username').focus();
            return;
        }

        // Create modal HTML
        const modalHTML = `
            <div id="quick-login-modal" style="
                display: flex;
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0,0,0,0.8);
                z-index: 100000;
                justify-content: center;
                align-items: center;
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                backdrop-filter: blur(5px);
            ">
                <div style="
                    background: white;
                    padding: 40px;
                    border-radius: 20px;
                    box-shadow: 0 20px 60px rgba(0,0,0,0.4);
                    width: 380px;
                    max-width: 90%;
                    position: relative;
                ">
                    <button onclick="document.getElementById('quick-login-modal').style.display='none'" style="
                        position: absolute;
                        top: 15px;
                        right: 15px;
                        background: none;
                        border: none;
                        font-size: 20px;
                        cursor: pointer;
                        color: #999;
                    ">&times;</button>
                    <h3 style="margin: 0 0 10px 0; color: #1b5e20; text-align: center; font-weight: 800;">
                        🔐 Super Admin
                    </h3>
                    <p style="text-align: center; color: #666; font-size: 14px; margin-bottom: 25px;">Masukkan kredensial untuk akses dashboard.</p>
                    <form id="quick-login-form">
                        <div style="margin-bottom: 15px;">
                            <label style="display: block; margin-bottom: 8px; color: #333; font-weight: 600; font-size: 13px;">Username</label>
                            <input type="text" id="quick-username" required placeholder="superadmin" style="
                                width: 100%;
                                padding: 12px;
                                border: 2px solid #eee;
                                border-radius: 10px;
                                font-size: 15px;
                                box-sizing: border-box;
                                outline: none;
                                transition: border-color 0.3s;
                            " onfocus="this.style.borderColor='#1b5e20'" onblur="this.style.borderColor='#eee'">
                        </div>
                        <div style="margin-bottom: 25px; position: relative;">
                            <label style="display: block; margin-bottom: 8px; color: #333; font-weight: 600; font-size: 13px;">Password</label>
                            <input type="password" id="quick-password" required placeholder="••••••••" style="
                                width: 100%;
                                padding: 12px;
                                padding-right: 45px;
                                border: 2px solid #eee;
                                border-radius: 10px;
                                font-size: 15px;
                                box-sizing: border-box;
                                outline: none;
                                transition: border-color 0.3s;
                            " onfocus="this.style.borderColor='#1b5e20'" onblur="this.style.borderColor='#eee'">
                            <button type="button" id="toggle-quick-pass" style="
                                position: absolute;
                                right: 10px;
                                top: 38px;
                                background: none;
                                border: none;
                                cursor: pointer;
                                color: #ccc;
                                font-size: 18px;
                            "><i class="fas fa-eye"></i></button>
                        </div>
                        <div id="quick-login-error" style="
                            color: #d32f2f;
                            font-size: 13px;
                            margin-bottom: 20px;
                            display: none;
                            text-align: center;
                            background: #ffebee;
                            padding: 10px;
                            border-radius: 8px;
                        "></div>
                        <button type="submit" style="
                            width: 100%;
                            padding: 14px;
                            background: #1b5e20;
                            color: white;
                            border: none;
                            border-radius: 10px;
                            font-size: 16px;
                            font-weight: 700;
                            cursor: pointer;
                            transition: all 0.3s;
                        " onmouseover="this.style.background='#0d3810'; this.style.transform='translateY(-2px)'" onmouseout="this.style.background='#1b5e20'; this.style.transform='translateY(0)'">
                            Masuk Dashboard
                        </button>
                    </form>
                    <div style="
                        margin-top: 25px;
                        padding-top: 20px;
                        border-top: 1px solid #eee;
                        font-size: 12px;
                        color: #bbb;
                        text-align: center;
                    ">
                        Shortcut: <kbd style="background: #f4f4f4; color: #666; padding: 2px 6px; border-radius: 4px; border: 1px solid #ddd;">Ctrl+Shift+L</kbd>
                    </div>
                </div>
            </div>
        `;

        // Insert modal into page
        document.body.insertAdjacentHTML('beforeend', modalHTML);

        // Password Toggle Logic
        const passInput = document.getElementById('quick-password');
        const toggleBtn = document.getElementById('toggle-quick-pass');
        toggleBtn.addEventListener('click', () => {
            const type = passInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passInput.setAttribute('type', type);
            toggleBtn.innerHTML = type === 'password' ? '<i class="fas fa-eye"></i>' : '<i class="fas fa-eye-slash"></i>';
        });

        // Handle form submission
        document.getElementById('quick-login-form').addEventListener('submit', async function (e) {
            e.preventDefault();

            const username = document.getElementById('quick-username').value;
            const password = document.getElementById('quick-password').value;
            const errorDiv = document.getElementById('quick-login-error');

            try {
                // Meticulous Path Detection
                // Find where this script is located to determine root
                const scripts = document.getElementsByTagName('script');
                let pathPrefix = './';
                for (let i = 0; i < scripts.length; i++) {
                    const src = scripts[i].getAttribute('src');
                    if (src && src.includes('js/quick_access.js')) {
                        // If src is "js/quick_access.js", we are in root
                        // If src is "../js/quick_access.js", we are in a subfolder
                        const match = src.match(/^(\.\.\/)+/);
                        if (match) pathPrefix = match[0];
                        break;
                    }
                }

                // Protocol Check
                const isLocalFile = window.location.protocol === 'file:';
                if (isLocalFile) {
                    console.warn('Superadmin Login: Running on file:// protocol. PHP execution requires a web server (XAMPP/Apache).');
                }

                const response = await fetch(`${pathPrefix}api/auth.php?action=login`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ user: username, pass: password })
                });

                if (!response.ok) {
                    throw new Error(`HTTP Error ${response.status}: ${response.statusText}`);
                }

                const data = await response.json();

                if (data.success) {
                    loginAttempts = 0;
                    sessionStorage.setItem('superadmin_logged_in', 'true');
                    sessionStorage.setItem('superadmin_user', username);
                    try { sessionStorage.setItem('cms_mi_raden_rahmat_access', Date.now().toString()); } catch (err) {}
                    var redirect = (typeof window.REDIRECT_AFTER_LOGIN !== 'undefined' && window.REDIRECT_AFTER_LOGIN) ? window.REDIRECT_AFTER_LOGIN : 'superadmin/index.html';
                    window.location.href = pathPrefix + redirect;
                } else {
                    loginAttempts++;
                    errorDiv.textContent = `Gagal: ${data.message || 'Username/Password salah'} (${loginAttempts}/3)`;
                    errorDiv.style.display = 'block';

                    if (loginAttempts >= 3) {
                        setTimeout(() => {
                            const modal = document.getElementById('quick-login-modal');
                            if (modal) modal.style.display = 'none';
                            loginAttempts = 0;
                        }, 1200);
                    }
                }
            } catch (error) {
                const protocolInfo = window.location.protocol === 'file:' ? '<br><small style="color:#d32f2f">Note: file:// detected. Gunakan XAMPP/Web Server.</small>' : '';
                errorDiv.innerHTML = `<strong>Koneksi Gagal:</strong><br><span style="font-size:11px; font-family:monospace;">${error.message}</span>${protocolInfo}`;
                errorDiv.style.display = 'block';
                console.error('Superadmin Login Error:', error);
            }
        });

        // Focus username field
        document.getElementById('quick-username').focus();
    }

    // Add subtle footer link for mobile/accessibility
    function addFooterLink() {
        // Wait for DOM to be ready
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', _add);
        } else {
            _add();
        }

        function _add() {
            const footer = document.querySelector('footer');
            if (!footer) return;

            // Meticulous Path Detection for Image
            const scripts = document.getElementsByTagName('script');
            let pathPrefix = './';
            for (let i = 0; i < scripts.length; i++) {
                const src = scripts[i].getAttribute('src');
                if (src && src.includes('js/quick_access.js')) {
                    const match = src.match(/^(\.\.\/)+/);
                    if (match) pathPrefix = match[0];
                    break;
                }
            }

            const linkContainer = document.createElement('div');
            linkContainer.style.textAlign = 'center';
            linkContainer.style.marginTop = '0cm';
            linkContainer.style.padding = '15px 10px';
            linkContainer.style.borderRadius = '12px';
            linkContainer.style.fontSize = '10px';

            const link = document.createElement('a');
            link.href = 'https://radenmasdewoo.netlify.app/';
            link.style.textDecoration = 'none';
            link.style.display = 'inline-block';
            link.innerHTML = `
                <img src="${pathPrefix}RMD_emas.png" 
                     alt="Raden Mas Dewo - Branding SMP Raden Rahmat" 
                     style="max-height: 91px; 
                            width: auto; 
                            filter: drop-shadow(0 4px 8px rgba(0, 0, 0, 0.1));
                            transition: all 0.3s ease;
                            opacity: 1;
                            display: block;"
                     onmouseover="this.style.transform='scale(1.1)'; this.style.filter='drop-shadow(0 8px 16px rgba(0, 0, 0, 0.15))';"
                     onmouseout="this.style.transform='scale(1)'; this.style.filter='drop-shadow(0 4px 8px rgba(0, 0, 0, 0.1))';">
            `;
            link.style.textDecoration = 'none';
            // Removed internal login trigger as per user request to go to external URL directly

            linkContainer.appendChild(link);
            footer.appendChild(linkContainer);
        }
    }

    addFooterLink();

    // Close modal on ESC key
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
            const modal = document.getElementById('quick-login-modal');
            if (modal) {
                modal.style.display = 'none';
            }
        }
    });

})();
