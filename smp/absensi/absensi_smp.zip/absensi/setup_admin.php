<?php
require_once 'config.php';
// Tambah akun admin/guru awal - HAPUS FILE INI SETELAH DIGUNAKAN!
$data_guru = [
    ['nama'=>'Administrator', 'username'=>'admin', 'password'=>'admin123', 'kelas'=>'7A'],
    ['nama'=>'Guru Kelas 7B', 'username'=>'guru7b', 'password'=>'guru123', 'kelas'=>'7B'],
    ['nama'=>'Guru Kelas 8A', 'username'=>'guru8a', 'password'=>'guru123', 'kelas'=>'8A'],
];
foreach($data_guru as $g){
    $pass = password_hash($g['password'], PASSWORD_DEFAULT);
    $stmt = $conn->prepare("INSERT IGNORE INTO guru (nama,username,password,kelas) VALUES (?,?,?,?)");
    $stmt->bind_param("ssss", $g['nama'], $g['username'], $pass, $g['kelas']);
    $stmt->execute();
}
echo "<h2>Setup berhasil! Akun guru telah dibuat.</h2>";
echo "<p><b>Hapus file setup_admin.php setelah ini!</b></p>";
echo "<a href='login.php'>Ke Halaman Login</a>";
?>
